// writeRealTimeData to gdb

var now = (new Date()).getSeconds()   // get current seconds
var xFloat, xInt, xString, xBool
if (now >= 20 && now <= 30){
	xFloat = Math.PI
    xInt = 5
    xString = "now"
    xBool = true
}else{
    xFloat = Math.random()
    xInt = Math.floor(Math.random() * (5 - 1 + 1) + 1)
    xString = getNowTime()   // get currentTime of gdb
    xBool = now % 2 === 0
}
writeFloatRtData(["calc"], [["xFloat"]],[[xFloat]])
writeIntRtData(["calc"], [["xInt"]], [[xInt]])
writeStringRtData(["calc"], [["xString"]], [[xString]])
writeBoolRtData(["calc"], [["xBool"]], [[xBool]])

