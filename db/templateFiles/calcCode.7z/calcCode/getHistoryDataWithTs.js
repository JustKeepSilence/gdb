// get history data with given timeStamp

var zFloat
var st = getTimeDuration(-60)
var et = getTimeDuration(-30)
var r = JSON.parse(getFloatHDataWithTs(["calc", "calc"], ["xFloat", "yFloat"], [[st, et], [st, et]]))["historicalData"]
// returned value format is {"historicalData":{"xFloat":[[1626884459,1626884489],[0.017115718,3.1415927]],"yFloat":[[1626884459,1626884489],[15,15]]},"times":1}
// you should judge whether returned data is null if is null == no historyData

if (r["xFloat"][0] !== null && r["yFloat"][0] !== null){
    zFloat = (r["xFloat"][1][0] + r["xFloat"][1][1] + r["yFloat"][1][0] + r["yFloat"][1][1]) / 2
}else{
    zFloat = 0.0
}
writeFloatRtData(["calc"], [["zFloat"]],[[zFloat]])