// mock 

var t1 = Math.random()
var t2 = Math.random() * 1.5
writeRtData([{"itemName": "t1", "value": t1, "groupName": "calc"},{"itemName": "t2", "value": t2, "groupName": "calc"}])  