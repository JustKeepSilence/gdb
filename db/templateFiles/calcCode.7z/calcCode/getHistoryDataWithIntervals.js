// get history data with intervals

var hFloat
var st = getTimeDuration(-60)
var et = getTimeDuration(-30)
var r = JSON.parse(getFloatHData(["calc", "calc"], ["xFloat", "yFloat"], [st, st], [et, et], [1, 1]))["historicalData"]
// returned value format is {"historicalData":{"xFloat":[[1626884459,1626884489],[0.017115718,3.1415927]],"yFloat":[[1626884459,1626884489],[15,15]]},"times":1}
// you should judge whether returned data is null if is null == no historyData

if (r["xFloat"][0] !== null && r["yFloat"][0] !== null){
    hFloat = ave(r["xFloat"][1]) + ave(r["yFloat"][1])
}else{
    hFloat = 0.0
}

function ave(a){
    var r = 0.0
    for (var i = 0; i < a.length; i++) {
        r += a[i]
    }
    return r / a.length
}

writeFloatRtData(["calc"], [["hFloat"]],[[hFloat]])