/**
 * here are guild about built-in js functions in calc in gdb
 */

/**
 * getRtData(groupNames, itemNames)==>get realTimeData from gdb
 *
 * @param(Array){groupNames}
 * @param(Array){itemNames}
 * @return(string)
 */

/**
 * write<T>RtData(groupNames, itemNames, itemValues)==>write realTimeData to gdb
 *
 * @param(Array){groupNames}
 * @param(Array){itemNames}
 * @param(Array){itemValues}
 */

/**
 * getNowTime() ==> get currentTime
 *
 * @return(String)
 */

/**
 * getTimeStamp(t)==>get unix timeStamp of the given time, time should be yyyy-mm-dd hh:mm:ss
 *
 * @param(string)
 * @return(Number)
 */

/**
 * getTimeDuration(t)==>get unix timeStamp of given timeDuration from now, scale is second
 *
 * @param(Number)
 * @return(Number)
 */

/**
 * get T history data with given timeStamp==> get<T>HDataWithTs(groupNames, itemNames, timeStamps)
 *
 * @param(Array){groupNames}
 * @param(Array){itemNames}
 * @param(Array){timeStamps}
 * @return(string)
 */

/**
 * get T history data with intervals ==> get<T>HData(groupNames, itemNames, startTimes, endTimes, intervals)
 *
 * @param(Array){groupNames}
 * @param(Array){itemNames}
 * @param(Array){starTimes}
 * @param(Array){endTimes}
 * @param(Array){intervals}
 * @return(string)
 */

/**
 * console string in gdbServer ==> console(c)
 *
 * @param(string){c}
 */
