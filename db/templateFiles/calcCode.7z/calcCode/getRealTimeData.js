// getRealTimeData from gdb

var r = JSON.parse(getRtData(["calc", "calc", "calc", "calc"], ["xFloat", "xInt", "xString", "xBool"]))  // getRealTimeData
var yFloat, yInt, yString, yBool
if (r["realTimeData"]["xFloat"]===null){
    // returned value format is {"realTimeData":{"xFloat": 1.1}}
    // you should judge whether returned realTimeData is null, if is null == no realTimeData
    yFloat = 0.0
}else{
    yFloat = (r.realTimeData.xFloat) * 2
}
if (r["realTimeData"]["xInt"]===null){
    // no realTimeData
    yInt = 0
}else{
    yInt = (r.realTimeData.xInt) * 3
}
if (r["realTimeData"]["xString"]===null){
    // no realTimeData
    yString = ""
}else{
    yString = r["realTimeData"]["xString"]
}
if (r["realTimeData"]["xBool"]===null){
    // no realTimeData
    yBool = false
}else{
    yBool = !r["realTimeData"]["xBool"]
}
writeFloatRtData(["calc"], [["yFloat"]],[[yFloat]])
writeIntRtData(["calc"], [["yInt"]], [[yInt]])
writeStringRtData(["calc"], [["yString"]], [[yString]])
writeBoolRtData(["calc"], [["yBool"]], [[yBool]])
